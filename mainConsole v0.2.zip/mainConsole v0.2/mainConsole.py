import sys
import os
import csv
from openpyxl import Workbook, load_workbook
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

class mainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.InitUI()

    def InitUI(self):
        self.setWindowTitle('Main Console')
        self.setGeometry(400, 200, 640, 640)

        self.buttonOpenFile     =   QPushButton('Open Data File', self)
        self.buttonMakeGraph    =   QPushButton('Make Graph', self)

        self.buttonOpenFile.setGeometry(50, 200, 120, 40)
        self.buttonMakeGraph.setGeometry(200, 200, 120, 40)

        self.exportImageIcon        =   QLabel(self)
        self.exportImageIcon.setPixmap(QPixmap('exportIcon.png'))
        self.exportImageIcon.setGeometry(320-(164/2), 400-54, 164, 54)

        self.exportExcel        =   QPushButton('Export to Excel', self)
        self.exportGraph        =   QPushButton('Export to Graph', self)
        self.btOpenExcel        =   QPushButton('Open Excel File', self)
        self.btOpenGraph        =   QPushButton('Open Graph File', self)

        self.exportExcel.setGeometry(120, 450, 120, 40)
        self.exportGraph.setGeometry(520-120, 450, 120, 40)
        self.btOpenExcel.setGeometry(120, 510, 120, 40)
        self.btOpenGraph.setGeometry(520-120, 510, 120, 40)

        self.exportExcel.clicked.connect(self.callExportExcel)
        self.exportGraph.clicked.connect(self.callExportGraph)
        self.btOpenExcel.clicked.connect(self.openExcel)
        self.btOpenGraph.clicked.connect(self.openGraph)

        self.show()

    def callExportExcel(self):
        with open('data\data.csv', newline='') as csvfile:
            CSVreader = csv.reader(csvfile)

            xlsxPrinter = Workbook()
            sheetPrinter = xlsxPrinter.active
            sheetPrinter.title = 'dataInf'

            sheetPrinter.append(['PH', 'Turb.', 'Temp.'])
            for Deliver in CSVreader:
                for i in range (0, len(Deliver)):
                    Deliver[i] = int(Deliver[i])
                sheetPrinter.append(Deliver)

            xlsxPrinter.save('export\exportExcel.xlsx')

        QMessageBox.about(self, 'Finish', 'Export Success')


    def callExportGraph(self):
        pass

    def openExcel(self):
        if os.system('export\exportExcel.xlsx') == 1:
            QMessageBox.about(self, 'Error', 'ERROR: File missed')

    def openGraph(self):
        if os.system('export\exportGraph.xlsx') == 1:
            QMessageBox.about(self, 'Error', 'ERROR: File missed')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = mainWindow()
    sys.exit(app.exec_())
