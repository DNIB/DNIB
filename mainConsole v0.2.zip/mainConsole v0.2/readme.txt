Update Information:
Version 0.1:
	Add buttons
	Add an image: Export the result

Version 0.2:
	Add two buttons:
		Open excel
		Open graph
	Add a function:
		Export to Excel
		Open excel
		Open graph
	Change:
		Change Image: Export the result