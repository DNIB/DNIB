import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

class mainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.InitUI()

    def InitUI(self):
        self.setWindowTitle('Main Console')
        self.setGeometry(400, 200, 640, 640)

        self.buttonOpenFile     =   QPushButton('Open Data File', self)
        self.buttonMakeGraph    =   QPushButton('Make Graph', self)

        self.buttonOpenFile.setGeometry(50, 200, 90, 30)
        self.buttonMakeGraph.setGeometry(150, 200, 90, 30)

        self.exportImageIcon        =   QLabel(self)
        self.exportImageIcon.setPixmap(QPixmap('exportIcon.png'))
        self.exportImageIcon.setGeometry(320-(164/2), 400-54, 164, 54)

        self.exportExcel        =   QPushButton('Export to Excel', self)
        self.exportGraph        =   QPushButton('Export to Graph', self)

        self.exportExcel.setGeometry(120, 450, 120, 40)
        self.exportGraph.setGeometry(520-120, 450, 120, 40)

        self.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = mainWindow()
    sys.exit(app.exec_())
