Update Information:
Version 0.1:
	Add buttons
	Add an image: Export the result
