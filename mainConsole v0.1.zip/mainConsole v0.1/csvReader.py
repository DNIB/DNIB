import csv
with open('data\data.csv', newline='') as csvfile:
    CSVreader = csv.reader(csvfile)

    for i in CSVreader:
        print (i)
